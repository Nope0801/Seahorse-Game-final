package com;

import com.seahorse.view.MainMenu;

public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(MainMenu::new);
    }
}
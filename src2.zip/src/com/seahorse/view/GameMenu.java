package com.seahorse.view;

public class GameMenu {
    
}

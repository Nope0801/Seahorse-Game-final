package com.seahorse.utils;

public class Position {
    
}

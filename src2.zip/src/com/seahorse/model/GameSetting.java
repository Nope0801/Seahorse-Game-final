package com.seahorse.model;

public class GameSetting {
    public static int screenHeight = 768;
    public static int screenWidth = 1366;
    // public static Graphics grp;
    public static int maxFPS = 60;
}

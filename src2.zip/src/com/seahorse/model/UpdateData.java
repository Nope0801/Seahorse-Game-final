package com.seahorse.model;

import java.util.ArrayList;

import com.seahorse.utils.UpdateComponent;

public class UpdateData {
    public static ArrayList<UpdateComponent> updateComponents = new ArrayList<UpdateComponent>();
}

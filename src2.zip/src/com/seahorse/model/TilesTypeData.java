package com.seahorse.model;

public class TilesTypeData {
    private TileType[][] TilesType;
    private enum TileType {
        T1, T2, BF, B, G, GF, RF, R, Y, YF, BC, YC, RC, GC;
    }
    

}

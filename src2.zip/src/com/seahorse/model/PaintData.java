package com.seahorse.model;

import com.seahorse.utils.PaintComponent;
import java.util.ArrayList;

public class PaintData {
    public static ArrayList<PaintComponent> paintEntities = new ArrayList<PaintComponent>();
}

package com.seahorse.model;

public enum EntityType {
    Null,
    SeaHorse,
}

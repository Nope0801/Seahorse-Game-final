package com.seahorse.controller;

public class MenuController {

}
